const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const MainJob = require('../../models/MainJob');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('chon_nghe')
    .setDescription('Chọn một nghề chính từ danh sách có sẵn.')
    .addStringOption(option =>
      option.setName('ten_nghe')
        .setDescription('Tên nghề bạn muốn chọn (ví dụ: Nông dân)')
        .setRequired(true)
    ),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const jobName = interaction.options.getString('ten_nghe');

    const jobData = await MainJob.findOne({ name: jobName });
    if (!jobData) {
      return interaction.reply({ content: `❌ Nghề **${jobName}** không tồn tại. Hãy kiểm tra lại tên nghề.`, ephemeral: true });
    }

    const userData = await User.findOne({ userId, guildId });
    if (!userData) {
      return interaction.reply({ content: '❌ Không tìm thấy dữ liệu người dùng.', ephemeral: true });
    }

    if (userData.mainJob && userData.mainJob.name) {
      return interaction.reply({ content: '❌ Con người không làm 1 lần 2 việc được! hãy `/bo_nghe` trước.', ephemeral: false });
    }

    userData.mainJob = {
      name: jobName,
      level: 1,
      xp: 0,
      lastSalary: null,
      hiredAt: new Date()
    };
    await userData.save();

    return interaction.reply(`✅ Bạn đã chọn làm **${jobName}**! Hãy bắt đầu sự nghiệp nào!`);
  }
};
