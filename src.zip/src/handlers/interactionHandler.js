const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); // Thêm các builder cần thiết
const tradeManager = require('../utils/tradeManager'); // Import tradeManager
const User = require('../models/User'); // Import User model nếu cần kiểm tra sâu hơn
const Logger = require('../utils/logger'); // Import Logger

// --- Các hàm helper cho giao diện trade (Sẽ cần triển khai chi tiết sau) ---

/**
 * Tạo Embed hiển thị trạng thái giao dịch hiện tại.
 * @param {object} tradeState - Trạng thái giao dịch từ tradeManager
 * @returns {Promise<EmbedBuilder>} Embed đã được tạo
 */
async function generateTradeEmbed(tradeState) {
    // TODO: Tạo embed chi tiết hơn ở các bước sau
    // Lấy thông tin user A, user B
    // Lấy offer của A, B (items, money)
    // Tính toán giá trị valueA, valueB, diff, percentDiff (dùng hàm từ tradeUtils.js)
    // Hiển thị thông tin trong embed

    const { valid, valueA, valueB, diff, percentDiff } = await require('../utils/tradeUtils').checkValueDifference(tradeState.userA.offer, tradeState.userB.offer);

    const embed = new EmbedBuilder()
        .setTitle(` Giao dịch: ${tradeState.userA.id} vs ${tradeState.userB.id}`) // Tạm thời hiển thị ID
        .setDescription('Sử dụng các nút bên dưới để thêm/bớt vật phẩm/tiền và xác nhận.')
        .setColor(valid ? 'Green' : 'Orange') // Màu xanh nếu hợp lệ, cam nếu không
        .addFields(
            { name: `Đề nghị của User A ${tradeState.userA.confirmed ? '✅' : ''}`, value: `Tiền: ${tradeState.userA.offer.money.toLocaleString()} VNĐ\nVật phẩm: ${tradeState.userA.offer.items.size > 0 ? [...tradeState.userA.offer.items.entries()].map(([id, qty]) => `\`${id}\` (x${qty})`).join(', ') : 'Không có'}`, inline: true },
            { name: `Đề nghị của User B ${tradeState.userB.confirmed ? '✅' : ''}`, value: `Tiền: ${tradeState.userB.offer.money.toLocaleString()} VNĐ\nVật phẩm: ${tradeState.userB.offer.items.size > 0 ? [...tradeState.userB.offer.items.entries()].map(([id, qty]) => `\`${id}\` (x${qty})`).join(', ') : 'Không có'}`, inline: true },
            { name: 'Giá trị Ước tính', value: `A: ${valueA.toLocaleString()} VNĐ\nB: ${valueB.toLocaleString()} VNĐ`, inline: false },
            { name: 'Chênh lệch', value: `${diff.toLocaleString()} VNĐ (${percentDiff.toFixed(1)}%) - ${valid ? 'Hợp lệ (<= 20%)' : 'Không hợp lệ (> 20%)'}`, inline: false }
        )
        .setFooter({text: `Trade ID: ${tradeState.tradeId} | Cập nhật lần cuối`})
        .setTimestamp(tradeState.lastUpdate);

    return embed;
}

/**
 * Tạo các ActionRow chứa các nút điều khiển giao dịch.
 * @param {object} tradeState - Trạng thái giao dịch
 * @returns {ActionRowBuilder[]} Mảng các ActionRowBuilder
 */
function generateTradeButtons(tradeState) {
    // TODO: Tạo các nút chi tiết hơn ở bước sau
    // Logic disable nút confirm nếu giá trị không hợp lệ hoặc chưa có offer?
    const { valid } = require('../utils/tradeUtils').checkValueDifference(tradeState.userA.offer, tradeState.userB.offer).valid; // Tạm tính lại (cần tối ưu sau)

    const tradeId = tradeState.tradeId;
    const userA_id = tradeState.userA.id;
    const userB_id = tradeState.userB.id;

    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`trade_add_item_${tradeId}_${userA_id}`).setLabel('A: Thêm Đồ').setStyle(ButtonStyle.Secondary).setEmoji('➕'),
        new ButtonBuilder().setCustomId(`trade_add_money_${tradeId}_${userA_id}`).setLabel('A: Thêm Tiền').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
        // TODO: Nút xóa đồ/tiền
        new ButtonBuilder().setCustomId(`trade_confirm_${tradeId}_${userA_id}`).setLabel('A: Xác nhận').setStyle(tradeState.userA.confirmed ? ButtonStyle.Success : ButtonStyle.Primary).setDisabled(!valid && !tradeState.userA.confirmed), // Disable nếu giá trị ko hợp lệ và chưa confirm
        new ButtonBuilder().setCustomId(`trade_cancel_${tradeId}_${userA_id}`).setLabel('A: Hủy').setStyle(ButtonStyle.Danger)
    );
    const row2 = new ActionRowBuilder().addComponents(
         new ButtonBuilder().setCustomId(`trade_add_item_${tradeId}_${userB_id}`).setLabel('B: Thêm Đồ').setStyle(ButtonStyle.Secondary).setEmoji('➕'),
        new ButtonBuilder().setCustomId(`trade_add_money_${tradeId}_${userB_id}`).setLabel('B: Thêm Tiền').setStyle(ButtonStyle.Secondary).setEmoji('💰'),
        // TODO: Nút xóa đồ/tiền
        new ButtonBuilder().setCustomId(`trade_confirm_${tradeId}_${userB_id}`).setLabel('B: Xác nhận').setStyle(tradeState.userB.confirmed ? ButtonStyle.Success : ButtonStyle.Primary).setDisabled(!valid && !tradeState.userB.confirmed),
        new ButtonBuilder().setCustomId(`trade_cancel_${tradeId}_${userB_id}`).setLabel('B: Hủy').setStyle(ButtonStyle.Danger)
    );

    return [row1, row2];
}

/**
 * Bắt đầu collector lắng nghe các tương tác trên giao diện trade.
 * @param {import('discord.js').Interaction} originalInteraction - Tương tác gốc (button accept) để update.
 * @param {object} tradeState - Trạng thái giao dịch.
 */
function startTradeInterfaceCollector(originalInteraction, tradeState) {
    const channel = originalInteraction.channel;
    if (!channel) return;

    const tradeId = tradeState.tradeId;
    const messageId = originalInteraction.message.id;

    // Lắng nghe tất cả button interactions trên kênh đó
    // Cần filter kỹ hơn trong 'collect'
    const collector = channel.createMessageComponentCollector({
        filter: i => i.message.id === messageId && i.customId.startsWith(`trade_`) && i.customId.includes(tradeId), // Lọc theo message và tradeId
        time: 15 * 60 * 1000 // Timeout 15 phút không hoạt động
    });

    tradeState.collector = collector; // Lưu collector vào state để có thể dừng từ bên ngoài

    collector.on('collect', async interaction => {
        const trade = tradeManager.getActiveTrade(tradeId);
        // Kiểm tra xem trade còn tồn tại không
        if (!trade) {
            interaction.reply({ content: 'Giao dịch này không còn tồn tại.', ephemeral: true }).catch(()=>{});
            collector.stop();
            return;
        }

        const userId = interaction.user.id;
        const customId = interaction.customId;

        // Phân tích customId để biết hành động và người thực hiện
        const parts = customId.split('_');
        const action = parts[1];
        // const tId = parts[2]; // redundant
        const actorId = parts[parts.length - 1]; // ID người bấm nút luôn ở cuối

        // Chỉ user A hoặc user B mới được tương tác với nút của mình
        if (userId !== actorId || (userId !== trade.userA.id && userId !== trade.userB.id)) {
            return interaction.reply({ content: 'Đây không phải nút dành cho bạn!', ephemeral: true });
        }

        Logger.info(`[Trade ${tradeId}] User ${userId} performed action: ${action}`);

        // TODO: Xử lý từng action (add_item, add_money, confirm, cancel)
        // - Mở modal cho add_item, add_money
        // - Xử lý logic khi modal được submit
        // - Cập nhật trade state bằng tradeManager.updateActiveTrade()
        // - Xử lý logic confirm (check value, check cả 2 confirm) -> thực hiện trade hoặc reset confirm
        // - Xử lý logic cancel -> gọi tradeManager.removeActiveTrade()
        // - Sau mỗi action hợp lệ, tính toán lại embed/buttons và update message:
        //      const updatedEmbed = await generateTradeEmbed(trade);
        //      const updatedButtons = generateTradeButtons(trade);
        //      await interaction.update({ embeds: [updatedEmbed], components: updatedButtons });

        // ---- XỬ LÝ NÚT HỦY LUÔN Ở ĐÂY ----
        if (action === 'cancel') {
            tradeManager.removeActiveTrade(tradeId);
            // Lấy tên người dùng từ cache hoặc fetch nếu cần
             const initiatorName = interaction.guild?.members.cache.get(trade.userA.id)?.user.username || trade.userA.id;
             const targetName = interaction.guild?.members.cache.get(trade.userB.id)?.user.username || trade.userB.id;
            await interaction.update({
                content: ` Giao dịch giữa ${initiatorName} và ${targetName} đã bị hủy bởi ${interaction.user.username}.`,
                embeds: [],
                components: []
            });
            collector.stop('cancelled');
            return; // Dừng xử lý tiếp
        }
         // ---- KẾT THÚC XỬ LÝ NÚT HỦY ----

        // Placeholder cho các nút khác - cần defer/reply/update phù hợp
        await interaction.reply({ content: `Đã nhận hành động: ${action} (Chưa xử lý)`, ephemeral: true });


    });

    collector.on('end', (collected, reason) => {
        const trade = tradeManager.getActiveTrade(tradeId);
        if (trade && reason !== 'cancelled' && reason !== 'trade_removed') { // Chỉ dọn dẹp nếu chưa bị hủy/xóa bởi lý do khác
            Logger.info(`[Trade ${tradeId}] Collector ended. Reason: ${reason}`);
            tradeManager.removeActiveTrade(tradeId);
            // Cập nhật tin nhắn gốc thành timeout/hết hạn
             trade.interaction?.editReply({ content: ' Giao dịch đã kết thúc do hết thời gian hoặc lỗi.', embeds: [], components: [] }).catch(()=>{});
        }
    });
}

// --- MODULE EXPORTS ---
module.exports = (client) => {
  // Load các handler buttons/selects từ file như cũ (nếu có)
  client.buttons = new Map();
  client.selectMenus = new Map();

  // Load Buttons
  const buttonPath = path.join(__dirname, '../interactions/buttons');
  if (fs.existsSync(buttonPath)){ // Kiểm tra thư mục tồn tại
      fs.readdirSync(buttonPath).filter(file => file.endsWith('.js')).forEach(file => { // Thêm filter .js
        try { // Thêm try catch cho require
            const button = require(path.join(buttonPath, file)); // Sửa đường dẫn require
            if (button.customId && typeof button.execute === 'function'){ // Kiểm tra kỹ hơn
                client.buttons.set(button.customId, button);
            } else {
                Logger.warn(`Button handler at ${file} is missing customId or execute function.`);
            }
        } catch (err) {
             Logger.error(`Failed to load button handler ${file}:`, err);
        }
      });
  } else {
       Logger.warn(`Button directory not found: ${buttonPath}`);
  }


  // Load Select Menus
  const selectPath = path.join(__dirname, '../interactions/selects');
   if (fs.existsSync(selectPath)) { // Kiểm tra thư mục tồn tại
      fs.readdirSync(selectPath).filter(file => file.endsWith('.js')).forEach(file => { // Thêm filter .js
        try { // Thêm try catch cho require
            const menu = require(path.join(selectPath, file)); // Sửa đường dẫn require
            if (menu.customId && typeof menu.execute === 'function'){ // Kiểm tra kỹ hơn
                 client.selectMenus.set(menu.customId, menu);
            } else {
                Logger.warn(`Select menu handler at ${file} is missing customId or execute function.`);
            }
        } catch (err) {
            Logger.error(`Failed to load select menu handler ${file}:`, err);
        }
      });
   } else {
        Logger.warn(`Select menu directory not found: ${selectPath}`);
   }


  // --- SỰ KIỆN INTERACTION CREATE ---
  client.on('interactionCreate', async (interaction) => {
    // Không log tất cả customId ở đây nữa để tránh spam log trade buttons
    // console.log(`[INTERACTION] ${interaction.customId} | ${interaction.user.tag}`);

    try {
        // --- XỬ LÝ TRADE BUTTONS TRƯỚC ---
        if (interaction.isButton()) {
            const customId = interaction.customId;
            // Log riêng cho trade buttons nếu cần debug
            if (customId.startsWith('trade_')) {
                 Logger.info(`[Interaction] Trade Button Clicked: ${customId} by ${interaction.user.tag}`);
            }

            if (customId.startsWith('trade_accept_') || customId.startsWith('trade_decline_')) {
              // Acknowledge ngay để tránh timeout
              await interaction.deferUpdate(); 
              const tradeId = customId.split('_')[2];
              const pendingTrade = tradeManager.getPendingTrade(tradeId);
              if (!pendingTrade) {
                  return interaction.editReply({ content: 'Lời mời giao dịch này không còn hợp lệ hoặc đã hết hạn.', components: [], embeds: [] });
              }
              if (interaction.user.id !== pendingTrade.targetId) {
                  // Sử dụng update() thay vì reply() nếu đã defer
                  return interaction.editReply({ content: 'Bạn không phải là người nhận lời mời này!', components: [], embeds: [] });
              }
          
              try {
                  if (customId.startsWith('trade_decline_')) {
                      tradeManager.removePendingTrade(tradeId);
                      const initiator = await client.users.fetch(pendingTrade.initiatorId).catch(() => null);
                      await interaction.editReply({ content: `Bạn đã từ chối lời mời giao dịch từ ${initiator?.username || 'người dùng không rõ'}.`, components: [], embeds: [] });
                  } else { // Accept
                      tradeManager.removePendingTrade(tradeId);
                      if (tradeManager.isUserInTrade(pendingTrade.initiatorId) || tradeManager.isUserInTrade(pendingTrade.targetId)) {
                          return interaction.editReply({ content: '❌ Một trong hai người đã bắt đầu giao dịch khác trong lúc chờ đợi.', components: [], embeds: [] });
                      }
                      const initialTradeState = tradeManager.createActiveTrade(
                          tradeId,
                          pendingTrade.initiatorId,
                          pendingTrade.targetId,
                          pendingTrade.guildId,
                          pendingTrade.channelId,
                          interaction.message.id,
                          interaction
                      );
                      if (!initialTradeState) {
                          return interaction.editReply({ content: '❌ Có lỗi xảy ra khi bắt đầu giao dịch.', components: [], embeds: [] });
                      }
                      const tradeEmbed = await generateTradeEmbed(initialTradeState);
                      const tradeButtons = generateTradeButtons(initialTradeState);
                      const initiator = await client.users.fetch(pendingTrade.initiatorId).catch(() => null);
                      const target = await client.users.fetch(pendingTrade.targetId).catch(() => null);
                      await interaction.editReply({
                          content: `Giao dịch giữa ${initiator?.username || '??'} và ${target?.username || '??'} đã bắt đầu!`,
                          embeds: [tradeEmbed],
                          components: tradeButtons
                      });
                      startTradeInterfaceCollector(interaction, initialTradeState);
                  }
              } catch (err) {
                  Logger.error(`[Trade ${tradeId}] Error processing trade action:`, err);
                  // Nếu xảy ra lỗi, cập nhật lại tin nhắn để tránh "interaction failed"
                  await interaction.editReply({ content: '❌ Đã xảy ra lỗi khi xử lý giao dịch.', components: [], embeds: [] });
              }
              return;
          }
             // ---- Xử lý các nút của giao diện trade đang hoạt động ----
             // (Logic này sẽ nằm trong startTradeInterfaceCollector, đoạn code trên chỉ xử lý Accept/Decline ban đầu)
             // Nếu collector đang chạy, nó sẽ tự xử lý các nút như add_item, confirm, cancel,...
        }

      // --- XỬ LÝ CÁC BUTTON/SELECT MENU KHÁC (TỪ FILE) ---
      if (interaction.isButton()) {
        // console.log('Button Clicked:', interaction.customId); // Log này có thể giữ lại nếu muốn
        const handler = client.buttons.get(interaction.customId);
        if (handler) {
            await handler.execute(interaction);
            return; // Đã xử lý bởi handler từ file
        }
        // Nếu không tìm thấy handler từ file và không phải trade button đã xử lý -> có thể là nút cũ/lỗi
        // Logger.warn(`No handler found for button: ${interaction.customId}`);

      } else if (interaction.isStringSelectMenu()) {
        // console.log('Select Menu Used:', interaction.customId);
        const handler = client.selectMenus.get(interaction.customId);
        if (handler) {
             await handler.execute(interaction);
             return; // Đã xử lý bởi handler từ file
        }
         // Logger.warn(`No handler found for select menu: ${interaction.customId}`);
      }

        // --- XỬ LÝ SLASH COMMANDS (NẾU CÓ TRONG HANDLER NÀY) ---
        // Nếu bạn xử lý slash command ở handler khác (vd: commandHandler.js) thì không cần đoạn này
        if (interaction.isChatInputCommand()) {
             const command = client.commands.get(interaction.commandName); // Giả sử client.commands tồn tại
             if (command) {
                 // Logger.info(`Executing command: ${interaction.commandName}`);
                 await command.execute(interaction, client); // Truyền client nếu cần
             } else {
                 Logger.error(`No command matching ${interaction.commandName} was found.`);
                 await interaction.reply({ content: 'Lệnh không tồn tại!', ephemeral: true });
             }
         }

        // --- XỬ LÝ MODAL SUBMIT (SẼ CẦN CHO TRADE) ---
        if (interaction.isModalSubmit()) {
            // Logger.info(`Modal Submitted: ${interaction.customId}`);
            // TODO: Xử lý modal submit, ví dụ modal thêm đồ/tiền vào trade
            // Cần phân tích customId để biết modal này thuộc về trade nào và action gì
            // Ví dụ: if (interaction.customId.startsWith('trade_add_item_modal_')) { ... }
            await interaction.reply({ content: 'Đã nhận modal (chưa xử lý).', ephemeral: true });
        }

    } catch (err) {
      Logger.error('[Interaction Error]', err);
      try {
          if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: '❌ Đã xảy ra lỗi khi xử lý tương tác!', ephemeral: true });
          } else {
            await interaction.reply({ content: '❌ Đã xảy ra lỗi khi xử lý tương tác!', ephemeral: true });
          }
      } catch (replyError) {
          Logger.error('[Interaction Error] Failed to send error reply:', replyError);
      }
    }
  });
};